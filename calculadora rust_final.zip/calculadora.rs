use std::io;
fn suma (x: i32, y: i32){
    println!("El resultado es: {}", x+y);
}
fn resta (x: i32, y: i32){
    println!("El resultado es: {}", x-y);
}
fn multiplica (x: i32, y: i32){
    println!("El resultado es: {}", x*y);
}
fn divide (x: i32, y: i32) {
    let x1 = x as f64;
    let y1 = y as f64;
    let d: f64;
    d=x1/y1;
    println! ("El resultado es: {}", d);
}

fn main() {
    loop{
    println!("Bienvenido a la calculadora");
    println!("Elige una opcion:");
    println!("1:Suma");
    println!("2:Resta");
    println!("3:Multiplicacion");
    println!("4:Division");
    println!("5:Salir");
    println!("Cualquier otra seleccion reiniciara la calculadora");

    let mut seleccion = String::new();
    let mut a = String::new();
    let mut b = String::new();

    io::stdin().read_line(&mut seleccion)
        .ok()
        .expect("Fallo al leer linea");

    let seleccion: i32 = match seleccion.trim().parse() {
    Ok(num) => num,
    Err(_) => continue,
};

    if seleccion == 1 {
        println!("Indica el primer numero a sumar");
        io::stdin().read_line(&mut a)
            .ok()
            .expect("Fallo al leer linea");

        let a: i32 = match a.trim().parse() {
        Ok(num) => num,
        Err(_) => continue,
    };
        println!("Indica el segundo numero a sumar");
        io::stdin().read_line(&mut b)
            .ok()
            .expect("Fallo al leer linea");

        let b: i32 = match b.trim().parse() {
        Ok(num) => num,
        Err(_) => continue,
    };
        suma(a,b);
    }
    if seleccion == 2 {
        println!("Indica el primer numero a restar");
        io::stdin().read_line(&mut a)
            .ok()
            .expect("Fallo al leer linea");

        let a: i32 = match a.trim().parse() {
        Ok(num) => num,
        Err(_) => continue,
    };
        println!("Indica el segundo numero a restar");
        io::stdin().read_line(&mut b)
            .ok()
            .expect("Fallo al leer linea");

        let b: i32 = match b.trim().parse() {
        Ok(num) => num,
        Err(_) => continue,
    };
        resta(a,b);
    }
    if seleccion == 3 {
        println!("Indica el primer numero a multiplicar");
        io::stdin().read_line(&mut a)
            .ok()
            .expect("Fallo al leer linea");

        let a: i32 = match a.trim().parse() {
        Ok(num) => num,
        Err(_) => continue,
    };
        println!("Indica el segundo numero a multiplicar");
        io::stdin().read_line(&mut b)
            .ok()
            .expect("Fallo al leer linea");

        let b: i32 = match b.trim().parse() {
        Ok(num) => num,
        Err(_) => continue,
    };
        multiplica(a,b);
    }
    if seleccion == 4 {
        println!("Indica el primer numero a dividir");
        io::stdin().read_line(&mut a)
            .ok()
            .expect("Fallo al leer linea");

        let a: i32 = match a.trim().parse() {
        Ok(num) => num,
        Err(_) => continue,
    };
        println!("Indica el segundo numero a dividir");
        io::stdin().read_line(&mut b)
            .ok()
            .expect("Fallo al leer linea");

        let b: i32 = match b.trim().parse() {
        Ok(num) => num,
        Err(_) => continue,
    };
        divide(a,b);
    }

    if seleccion == 5 {break;}
}

}
