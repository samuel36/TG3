package main
import "fmt"
func main(){
  var opcion int
  var n1 float32
  var n2 float32
  var r float32
  fmt.Println("Elige la operación que quieres realizar")
  fmt.Println("1. Suma")
  fmt.Println("2. Resta")
  fmt.Println("3. Multiplicación")
  fmt.Println("4. Divsión")
  fmt.Scanln(&opcion)
  fmt.Println("Escribe el primer número")
  fmt.Scanln(&n1)
  fmt.Println("Escribe el segundo número")
  fmt.Scanln(&n2)

  switch opcion {
  case 1:
  r=n1+n2
  fmt.Println("El resultado de la suma es: " , r)
case 2:
  r = n1-n2
  fmt.Println("El resultado de la resta es: " , r)
case 3:
  r = n1*n2
  fmt.Println("El resultado de multiplicar los 2 números es: " , r)
case 4:
  r = n1/n2
  fmt.Println("El resultado de dividir el primer número entre el segundo es: " , r)
default:
  fmt.Println(" ***Error*** \n No es una opción válida ")
   }
    }
