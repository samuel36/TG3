package main

import (
	"net"
	"net/textproto"
	"log"
	"os/exec"
	"fmt"
	"bufio"
)

func main() {
	fmt.Printf("My hostname: %s", getMyHostname())
	ln, err := net.Listen("tcp", ":8082")
	if err != nil {
		log.Fatal("ERROR: ", err)
	} else {
		log.Print("Listening on port 8082")
		for {
			conn, err := ln.Accept()
			if err != nil {
				log.Fatal("ERROR: ", err)
				continue
			}
			go handleConnection(conn)
		}
	}
}

func handleConnection(conn net.Conn) {
	log.Print("New connection!")
	reader  := bufio.NewReader(conn)
	tpRead  := textproto.NewReader(reader)
	writer  := bufio.NewWriter(conn)
	tpWrite := textproto.NewWriter(writer)
	tpWrite.PrintfLine("Hello from %s", getMyHostname())
	tpWrite.PrintfLine("Commands: ping, end.")
	for {
		line, _ := tpRead.ReadLine()
		log.Print("RECV: ", line)
		if (line == "ping") {
			log.Print("SEND: pong")
			tpWrite.PrintfLine("pong")
		} else if (line == "end") {
			log.Print("RECV: end")
			tpWrite.PrintfLine("OK, bye!")
			break
		}
	}
	conn.Close()
}

func getMyHostname() ([]byte) {
	hostnameCmd, _ := exec.LookPath("hostname")
	hostname, _ := exec.Command(hostnameCmd).Output()
	return hostname
}
